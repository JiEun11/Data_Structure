package com.javaex.structure.fourth.exam;

public interface IPayrollManage {

    double pay = 0;

    public double getSalary(Position pos);

}

